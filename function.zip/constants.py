user_images_bucket_name = 'artifyc-user-images-qa'
users_table_name = 'Users'
s3_images_buffer_key = 'upload-buffer'